package hello.service;

import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import hello.model.PojoConFichero;
import hello.repository.PojoConFicheroRepository;
import hello.storage.StorageService;

@Service
public class UploadConPojoService {
	
	@Autowired
	PojoConFicheroRepository pojoConFicheroRepo;
	
	@Autowired
	StorageService storageService;
	
	
	/**
	 * 
	 * @param p Debe contener el atributo fileUrl a nulo; si no, su valor será ignorado
	 */
	public void add(PojoConFichero p, MultipartFile file) {
				
		String fileName = storageService.store(file);//Guarda la imagen
		//Guardamos nombre de la imagen almacenada en el atributo de la entidad
		p.setFileUrl(fileName);
		//Guardamos la entidad en la base de datos y en ella ya irá el nombre del archivo
		//en la correspondiente propiedad (fileUrl)
		pojoConFicheroRepo.save(p);
		
	}
	
	/** Método que devuelve una lista de entidades con sus ficheros
	 * a los que se les ha guardado dentro de su atributo URL
	 * el nombre de la URL images/nombredelarchivo.
	 * Este /images/ debe ser el mismo que el que hayamos dado en la clase 
	 * MvcConfig del paquete Hello*/
	
	public List<PojoConFichero> list() {
				
		List<PojoConFichero> partialResult = pojoConFicheroRepo.findAll();
		List<PojoConFichero> result = new LinkedList<PojoConFichero>(partialResult);
		
		for(int i = 0; i < partialResult.size(); i++) {
			String fileName = partialResult.get(i).getFileUrl();
			result.get(i).setFileUrl("/images/"+ fileName);
		}
						
		return result;
	}
	

}
