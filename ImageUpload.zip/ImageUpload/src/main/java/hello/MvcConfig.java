package hello;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

/** Permite hacer configuraciones de la parte MVC, sobre todo asociada a los controller
 * En este caso dice que cuando se hagan peticiones, por ejemplo, pintarlas en lugar de buscar
 * en /images (carpeta que no tenemos creada en nuestro proyecto), se haga en el sistema 
 * de ficheros (file:) ruta /files*/

@Configuration
@EnableWebMvc
public class MvcConfig extends WebMvcConfigurerAdapter {

	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		registry
			.addResourceHandler("/images/**")
			.addResourceLocations("file:files/");	
			
	}
	
	
	
	

}
