/**
 * Paquete con todos los reposotorios necesarios
 */
package com.salesianostriana.dam.repository;

