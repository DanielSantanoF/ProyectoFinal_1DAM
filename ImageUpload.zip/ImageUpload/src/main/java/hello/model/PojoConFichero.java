package hello.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;


/** - Una clase de entidad formada por un atributo cualquiera y un String con el nombre
 * del fichero a tratar
 * - En este ejemplo, se va a trabajar con esta entidad pero a la hora de subir 
 * la imagen, lo haremos dividiendo la parte de nuestra POJO "normal" (todo lo que no es la 
 * imagen o aquellos atributos que queramos recoger en un formulario y 
 * por otro lado, la imagen o fichero.
 * - Para ello, creamos otra clase llamada UploadFormBean que solo contendrá el 
 * campo "propiedadCuaqluiera" para separlo de la imagen. En casos más amplios, aquí irían
 * todos aquellos campos que queramos recoger del formulario que no sean el fichero*/

@Entity
public class PojoConFichero {
	
	@Id
	@GeneratedValue
	private Long id;
	
	
	private String propiedadCualquiera;
	
	//Atributo String que guardará la URL de nuestro archivo a subir
	private String fileUrl;
	
	public PojoConFichero() { }

	public String getPropiedadCualquiera() {
		return propiedadCualquiera;
	}

	public void setPropiedadCualquiera(String propiedadCualquiera) {
		this.propiedadCualquiera = propiedadCualquiera;
	}

	public String getFileUrl() {
		return fileUrl;
	}

	public void setFileUrl(String fileUrl) {
		this.fileUrl = fileUrl;
	}

	public Long getId() {
		return id;
	}
	
	
	

}
